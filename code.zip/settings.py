import os


ROOT_DIR = os.path.dirname(os.path.realpath(__file__))