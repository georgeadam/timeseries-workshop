from src.base.factory import Factory

normalizers = Factory()