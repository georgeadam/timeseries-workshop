from src.base.factory import Factory

trainers = Factory()