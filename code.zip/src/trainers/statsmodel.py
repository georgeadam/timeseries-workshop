from .trainer import Trainer
from .creation import trainers


class Statsmodel(Trainer):
    def fit(self, model, data, feeder):
        x, _ = feeder.feed(data)
        model.fit(x)


trainers.register_builder("statsmodel", Statsmodel)