from src.base.factory import Factory

inferers = Factory()