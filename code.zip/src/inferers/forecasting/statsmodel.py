from .inferer import Inferer

from ..creation import inferers


class Statsmodel(Inferer):
    def one_step_forecast(self, model, data, feeder):
        return model.predict(1)

    def n_step_forecast(self, model, data, feeder, n):
        return model.predict(n)


inferers.register_builder("statsmodel_forecasting", Statsmodel)
