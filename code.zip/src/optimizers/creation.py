from src.base.factory import Factory

optimizers = Factory()