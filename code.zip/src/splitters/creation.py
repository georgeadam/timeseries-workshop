from src.base.factory import Factory

splitters = Factory()