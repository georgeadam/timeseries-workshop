from src.base.factory import Factory

feeders = Factory()