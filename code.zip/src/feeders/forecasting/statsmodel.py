from ..creation import feeders
from ..feeder import Feeder


class Statsmodel(Feeder):
    def __init__(self, timesteps, **kwargs):
        self.timesteps = timesteps

    def feed(self, data):
        x = data[:, :, -1].reshape(-1)

        return x, x

    def future_steps(self, data, n):
        return data[:, : self.timesteps + n, -1]


feeders.register_builder("statsmodel_forecasting", Statsmodel)
