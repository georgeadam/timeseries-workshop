from src.base.factory import Factory

models = Factory()