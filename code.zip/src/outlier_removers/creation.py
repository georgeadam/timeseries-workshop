from src.base.factory import Factory

outlier_removers = Factory()