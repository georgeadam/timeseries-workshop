import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, average_precision_score, roc_auc_score

from ..creation import trackers
from ..tracker import Tracker


class Sklearn(Tracker):
    def __init__(self, partition):
        self.partition = partition

        self.patient_ids = []
        self.preds = []
        self.probs = []
        self.targets = []
        self.metrics = {"accuracy": [], "auc": [], "aupr": []}

    def track(self, model, data, feeder, inferer):
        preds, probs = self._get_predictions(model, data, feeder, inferer)
        targets = self._get_targets(data, feeder)

        self._track_patients(data.patient_ids)
        self._track_predictions(preds, probs)
        self._track_targets(targets)
        self._track_metrics(preds, probs, targets)

    def _track_metrics(self, preds, probs, targets):
        metrics = {"accuracy": accuracy_score(targets, preds),
                   "auc": roc_auc_score(targets, probs),
                   "aupr": average_precision_score(targets, probs)}

        for metric_name, metric_value in metrics.items():
            self.metrics[metric_name].append(metric_value)
            print("{}: {}".format(metric_name, metric_value))

    def _track_patients(self, patient_ids):
        self.patient_ids.append(patient_ids)

    def _track_predictions(self, preds, probs):
        self.preds.append(preds)
        self.probs.append(probs)

    def _track_targets(self, targets):
        self.targets.append(targets)

    def _get_predictions(self, model, data, feeder, inferer):
        preds = inferer.predict(model, data, feeder)
        probs = inferer.predict_proba(model, data, feeder)

        return preds, probs

    def _get_targets(self, data, feeder):
        _, y = feeder.feed(data)

        return y

    def save(self):
        np.save("{}_patient_ids.npy".format(self.partition), np.asanyarray(self.patient_ids, dtype=object))
        np.save("{}_preds.npy".format(self.partition), np.asanyarray(self.preds, dtype=object))
        np.save("{}_probs.npy".format(self.partition), np.asanyarray(self.probs, dtype=object))
        np.save("{}_targets.npy".format(self.partition), np.asanyarray(self.targets, dtype=object))
        pd.DataFrame(self.metrics).to_csv("{}_metrics.csv".format(self.partition), index=False)


trackers.register_builder("sklearn_classification", Sklearn)
