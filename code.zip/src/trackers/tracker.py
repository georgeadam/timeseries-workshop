import abc


class Tracker(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def track(self, model, data, feeder, inferer):
        raise NotImplementedError

    @abc.abstractmethod
    def _track_metrics(self, *args):
        raise NotImplementedError

    @abc.abstractmethod
    def _track_predictions(self, *args):
        raise NotImplementedError

    @abc.abstractmethod
    def _track_targets(self, targets):
        raise NotImplementedError

    @abc.abstractmethod
    def _get_predictions(self, model, data, feeder, inferer):
        raise NotImplementedError

    @abc.abstractmethod
    def _get_targets(self, data, feeder):
        raise NotImplementedError

    @abc.abstractmethod
    def save(self):
        raise NotImplementedError