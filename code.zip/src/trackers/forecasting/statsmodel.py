import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error

from ..creation import trackers
from ..tracker import Tracker


class Statsmodel(Tracker):
    def __init__(self, partition, n):
        self.partition = partition
        self.n = n

        self.patient_ids = []
        self.preds = []
        self.targets = []
        self.metrics = {"mse": []}

    def track(self, model, data, feeder, inferer):
        preds = self._get_predictions(model, data, feeder, inferer)
        targets = self._get_targets(data, feeder)

        self._track_patients(data.patient_ids)
        self._track_predictions(preds)
        self._track_targets(targets)
        self._track_metrics(preds, targets)

    def _track_metrics(self, preds, targets):
        metric_fns = {"mse": mean_squared_error}

        for metric_name, metric_fn in metric_fns.items():
            metric_value = metric_fn(targets[:, -preds.shape[1]:], preds)
            self.metrics[metric_name].append(metric_value)
            print("{}: {}".format(metric_name, metric_value))

    def _track_patients(self, patient_ids):
        self.patient_ids.append(patient_ids)

    def _track_predictions(self, preds):
        self.preds.append(preds)

    def _track_targets(self, targets):
        self.targets.append(targets)

    def _get_predictions(self, model, data, feeder, inferer):
        preds = inferer.n_step_forecast(model, data, feeder, self.n)

        return preds

    def _get_targets(self, data, feeder):
        y = feeder.future_steps(data, self.n)

        return y

    def save(self):
        np.save("{}_patient_ids.npy".format(self.partition), np.asanyarray(self.patient_ids, dtype=object))
        np.save("{}_preds.npy".format(self.partition), np.asanyarray(self.preds, dtype=object))
        np.save("{}_targets.npy".format(self.partition), np.asanyarray(self.targets, dtype=object))
        pd.DataFrame(self.metrics).to_csv("{}_metrics.csv".format(self.partition), index=False)


trackers.register_builder("statsmodel_forecasting", Statsmodel)
